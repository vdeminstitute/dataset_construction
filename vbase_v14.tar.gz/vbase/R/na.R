#' @export
allNA <- function(obj) {
    all(is.na(obj))
}

