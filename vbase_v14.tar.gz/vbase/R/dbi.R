#' Get schema name
#' @export
schema_name <- function(name) {
    unlist(strsplit(name, ".", fixed = TRUE))
}

#' Create a database table from a data.frame
#'@export
pg_create_table <- function(df, name, db, overwrite = FALSE, ...) {
    DBI::dbWriteTable(db,
        name = schema_name(name),
        value = df,
        row.names = FALSE,
        overwrite = overwrite, ...)
	return(invisible(NULL))
}

#' Create table types
#'@export
pg_create_table_types <- function(name, columns, types, db) {
    cols <- paste(paste(columns, types, sep = " "), collapse = ", ")
    query <- "CREATE TABLE " %^% name %^% "(" %^% cols %^% ");"
    pg_send_query(db, query)

}

#' Does a table exist in a database?
#'@export
pg_exists_table <- function(name, db) {
    DBI::dbExistsTable(db, name = schema_name(name))
}

#' Truncate a database table
#'@export
pg_truncate_table <- function(name, db) {
    pg_send_query(db, "TRUNCATE TABLE " %^% name %^% ";")
}

#' Append to a database table
#'@export
pg_append_table <- function(df, name, db) {
    DBI::dbWriteTable(db,
        name = schema_name(name),
        value = df,
        row.names = FALSE,
        append = TRUE)
	
    return(invisible(NULL))
}

#' @title Replace a PostgreSQL table
#' @description This function replaces a table in a PostgreSQL database with a new data frame.
#' @param df A data frame containing the new data to be inserted into the table.
#' @param name Character string with the name of the table to be replaced.
#' @param db A PostgreSQL database connection object.
#' @return Returns Null invisibly.
#' @export
pg_replace_table <- function(df, name, db) {
    pg_truncate_table(name, db)
    pg_append_table(df, name, db)
}

#' @title Drop a PostgreSQL table
#' @description This function drops a table from a PostgreSQL database.
#' @param name Character string with the name of the table to drop.
#' @param db A PostgreSQL database connection object.
#' @return Returns NULL invisibly.
#' @export
pg_drop_table <- function(name, db) {
    pg_send_query(db, sprintf("DROP TABLE %s;", name))
}


#' @title Send SQL query to database without expecting a return value
#' @param db Database connection.
#' @param query SQL query.
#' @return Returns NULL invisibly.
#' @export
pg_send_query <- function(db, query) {
    rs <- DBI::dbSendStatement(conn = db, statement = query)
	DBI::dbClearResult(rs)
	return(invisible(NULL))
}

#' @title Send SQL query to database and expecting a return
#' @description If you want to only send a query without expecting a return value, use \code{\link{pg_send_query}}.
#' @param db Database connection.
#' @param query SQL query.
#' @return Returns a data.frame.
#' @export
pg_get_query <- function(db, query) {
	DBI::dbGetQuery(db, query)
}

#'@export
pg_update_table <- function(df, name, db) {
    if (pg_exists_table(name, db)) {
        pg_truncate_table(name, db)
        pg_append_table(df, name, db)
    } else {
        pg_create_table(df, name, db)
    }
	return(invisible(NULL))
}

#'@export
pg_create_index <- function(column, name, db, unique_idx = FALSE) {
    if (unique_idx) {
        unique_text = "UNIQUE "
    } else {
        unique_text = ""
    }

    pg_send_query(db,
        "CREATE " %^% unique_text %^% "INDEX ON " %^%
        name %^% " (" %^% column %^% ");")
	return(invisible(NULL))
}

#' Prepare string for postgres query
#'
#' @export
pg_text <- function(v) {
    cat(paste0("'", paste0(v, collapse = "','"), "'"), sep = "\n")
}