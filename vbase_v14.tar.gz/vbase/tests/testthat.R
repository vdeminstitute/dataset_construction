library(testthat)
library(vbase)

test_check("vbase")
